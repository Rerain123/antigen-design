# Local workflow engineering report

Scientific Gate: CLOSED; DEVELOPMENT_UNREVIEWED; NOT_DEPLOYED.

| Node | Branch | State | Reason | Origin | Detail |
|---|---|---|---|---|---|
| N04 | bepipred | succeeded |  | NEW_EXECUTION |  |
| N03 | blast | succeeded |  | NEW_EXECUTION |  |
| N12 | cheap1 | succeeded |  | NEW_EXECUTION |  |
| N16 | codon | skipped | EXPRESSION_HOST_NOT_PROVIDED |  |  |
| N11 | design_inputs | succeeded |  | NEW_EXECUTION |  |
| N10 | developability | succeeded |  | NEW_EXECUTION |  |
| N09 | domains | succeeded |  | NEW_EXECUTION |  |
| N06 | epitope_map | succeeded |  | NEW_EXECUTION |  |
| N11 | formal0 | succeeded |  | NEW_EXECUTION |  |
| N11 | formal1 | succeeded |  | NEW_EXECUTION |  |
| N07 | glycosylation | succeeded |  | NEW_EXECUTION |  |
| N08 | homology | skipped | DATABASE_NOT_PROVIDED |  |  |
| N18 | local_delivery | succeeded |  | NEW_EXECUTION |  |
| N05 | netmhc | succeeded |  | NEW_EXECUTION |  |
| N01 | prediction | succeeded |  | NEW_EXECUTION |  |
| N11 | proposal0 | succeeded |  | NEW_EXECUTION |  |
| N11 | proposal1 | succeeded |  | NEW_EXECUTION |  |
| N12 | revision_design | succeeded | S28_ORIGINAL_PASS | INTERNAL_FACT |  |
| N12 | rx1_s14_af3 | succeeded |  | NEW_EXECUTION |  |
| N01 | structure | succeeded |  | NEW_EXECUTION |  |
| N02 | topology | succeeded |  | NEW_EXECUTION |  |
| N18 | wt_draft | succeeded |  | NEW_EXECUTION |  |
| N17 | wt_foldx | skipped | NO_COVERED_EXPLICIT_OPEN_SCAN_POSITION |  |  |
| N17 | wt_reference | succeeded |  | NEW_EXECUTION |  |
| N17 | wt_thermompnn | skipped | NO_COVERED_EXPLICIT_OPEN_SCAN_POSITION |  |  |
| N13 | z1_s14_bepipred | succeeded |  | NEW_EXECUTION |  |
| N10 | z1_s14_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z1_s14_epitope_map | succeeded |  | NEW_EXECUTION |  |
| N13 | z1_s14_netmhc | succeeded |  | NEW_EXECUTION |  |
| N13 | z1_s14_structure | succeeded |  | NEW_EXECUTION |  |

## Expert revision / engineering facts

Contract: t01-core-20260929-v1
Formal acceptance: NOT_ASSESSED
Proposals are nomination-only; full sequences, provenance and task budgets are in workflow.json.

| Candidate | Mutations | Disposition | S28 | FoldX execution / mean / valid repeats | Acceptance |
|---|---|---|---|---|---|
| candidate-36f8c247eb108629955ada39b1190c84f7520f4a1385c0071905b790e4f904c3 | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-94b08e23ac03be1c5ff52279f2ae9c127bcd8bce5b4a6fe1d03d4bd39a4a426b | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-09b0158541c340b519bb9c98e9ae9324ce762f9b19eee8775d828f344260616c | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-252f3b0d987efdf2bafe29bdb2bc5536b445bd488f68674f90c90f885aa483fb | 14 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-c181c2072d114175cda46c4d119e1cab544bf793f66d164177ed4a266e23e6b8 | 14 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-8fa47195480aa44b552721147a0f2595e7162cae3deec7a6a7df73d3926eb4c8 | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-daeaf0f6506db61a68cff3118298ee2a56622fa14329c1b2ee8c92d9718deaed | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-94b08e23ac03be1c5ff52279f2ae9c127bcd8bce5b4a6fe1d03d4bd39a4a426b | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-0ae21813d0b287896951613edebd281812fc5856dd18e11809d99f7683f5afb5 | 14 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-74bd9a1658f64b98d44679c07818b2c18e2f68443983d6faed8f94e13bcd6f1f | 13 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-82b52e319a768e38f4ed219d61940ba505777a4b5cab2f734b6a1d02a46a2031 | 15 | FORMAL_POOL | PASS | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-1c5fb6a35416a4058d7f3fb952f0881551b4a6847bda76b0ba34162d31b22775 | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-a416cbec58a0bcd4ed9defadb295a95974ad9d3f817ba22b48c178f4c9c192d9 | 14 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-dfed4782e4c7118026b37b05f57435b6aa1482cae3cf08d3106ef811e8568ae9 | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-afa1f2b6e5bec042ca781c19b1a12319c4e846e3d97e335454d7139a4e8b8032 | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-4d9dad849ded978cd454aaf6991dead8f533fee65519ac129e2cc5bd9aa5663a | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-d4e8d7b41223b30d07124e4718f25d6d9d19f3754ab286380c11a82b1de29a2d | 14 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-da6335a8ffbfd5e60c29b227eeb07decdf4d94929df9dd304ba3c24f865b4c12 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-455a465234773eee05469f89a5955e4e5a92cfb6c07756fbdbe03816adde1731 | 14 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-644db91013d39c0e3dd83c4f3322af0eb8cfa3bf38b37f82b54b131290ac4374 | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-9f8fb0bdbc92be79580f5b6a7c6dcdb58490c18c9d5e633de3ceedc3c2b9e134 | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-60bcc36c0a704ab90698df2e558ca5ca07661b5a0329cc9cf96a9ef0f6aab4d1 | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-7266863046491d615757190cc2b3b574dfc540d49eddab56b69fdaaaa2aa0df6 | 14 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-65523cbca6b2216f86b665b88045037d64be5389e6190a9c710977d7f6be63a8 | 13 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-f9d09db4513b36d31341d923885125575a688866e9f53280b12818becc9f5b21 | 14 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-a416cbec58a0bcd4ed9defadb295a95974ad9d3f817ba22b48c178f4c9c192d9 | 14 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-4ef011d2efe1972accea3b27c4eb9afb5ce2838dd0c8d31e942dfffcdb69eb8c | 14 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-94b08e23ac03be1c5ff52279f2ae9c127bcd8bce5b4a6fe1d03d4bd39a4a426b | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-a275b88c7e801a0da7e1dd547a5f4c37c2328e7ebdc21ab560e1e3c3f859dbd6 | 14 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-ab38d93bad8c0005011c8db9854bbea44e521989211991ed550515cf695f94ed | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-26124a3dc4b9284ac86e468953690e6c42b8339f4043ffa83709df8deaadb7d2 | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-4d9dad849ded978cd454aaf6991dead8f533fee65519ac129e2cc5bd9aa5663a | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-f98c5d9f9067de3a3ddf10f4e05c3980e5f94b3430e1f17c208f1872fa2fa67f | 15 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | 16 | REJECTED | FAIL | NOT_RUN / None / 0 | FAIL |

v2 thresholds: pending_calibration. Provisional task acceptance: NOT_ASSESSED
Scores are comparable only within the same dimension, mode and evidence group; no global rank.

| Candidate | Supplier | N13 / legacy L1 identity | L4 | Comparison before / after penalty | Acceptance score / provisional |
|---|---|---|---|---|---|
| candidate-36f8c247eb108629955ada39b1190c84f7520f4a1385c0071905b790e4f904c3 | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-94b08e23ac03be1c5ff52279f2ae9c127bcd8bce5b4a6fe1d03d4bd39a4a426b | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | None | None / None | None | None / None | None / FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | None | None / None | None | None / None | None / FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-09b0158541c340b519bb9c98e9ae9324ce762f9b19eee8775d828f344260616c | None | None / None | None | None / None | None / FAIL |
| candidate-252f3b0d987efdf2bafe29bdb2bc5536b445bd488f68674f90c90f885aa483fb | None | None / None | None | None / None | None / FAIL |
| candidate-c181c2072d114175cda46c4d119e1cab544bf793f66d164177ed4a266e23e6b8 | None | None / None | None | None / None | None / FAIL |
| candidate-8fa47195480aa44b552721147a0f2595e7162cae3deec7a6a7df73d3926eb4c8 | None | None / None | None | None / None | None / FAIL |
| candidate-daeaf0f6506db61a68cff3118298ee2a56622fa14329c1b2ee8c92d9718deaed | None | None / None | None | None / None | None / FAIL |
| candidate-94b08e23ac03be1c5ff52279f2ae9c127bcd8bce5b4a6fe1d03d4bd39a4a426b | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-0ae21813d0b287896951613edebd281812fc5856dd18e11809d99f7683f5afb5 | None | None / None | None | None / None | None / FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | None | None / None | None | None / None | None / FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | None | None / None | None | None / None | None / FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | None | None / None | None | None / None | None / FAIL |
| candidate-74bd9a1658f64b98d44679c07818b2c18e2f68443983d6faed8f94e13bcd6f1f | None | None / None | None | None / None | None / FAIL |
| candidate-82b52e319a768e38f4ed219d61940ba505777a4b5cab2f734b6a1d02a46a2031 | primary | NOT_ASSESSED / None | NOT_ASSESSED | 0.30474129584626175 / 0.20474129584626174 | None / NOT_ASSESSED |
| candidate-1c5fb6a35416a4058d7f3fb952f0881551b4a6847bda76b0ba34162d31b22775 | None | None / None | None | None / None | None / FAIL |
| candidate-a416cbec58a0bcd4ed9defadb295a95974ad9d3f817ba22b48c178f4c9c192d9 | None | None / None | None | None / None | None / FAIL |
| candidate-dfed4782e4c7118026b37b05f57435b6aa1482cae3cf08d3106ef811e8568ae9 | None | None / None | None | None / None | None / FAIL |
| candidate-afa1f2b6e5bec042ca781c19b1a12319c4e846e3d97e335454d7139a4e8b8032 | None | None / None | None | None / None | None / FAIL |
| candidate-4d9dad849ded978cd454aaf6991dead8f533fee65519ac129e2cc5bd9aa5663a | None | None / None | None | None / None | None / FAIL |
| candidate-d4e8d7b41223b30d07124e4718f25d6d9d19f3754ab286380c11a82b1de29a2d | None | None / None | None | None / None | None / FAIL |
| candidate-da6335a8ffbfd5e60c29b227eeb07decdf4d94929df9dd304ba3c24f865b4c12 | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | None | None / None | None | None / None | None / FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | None | None / None | None | None / None | None / FAIL |
| candidate-455a465234773eee05469f89a5955e4e5a92cfb6c07756fbdbe03816adde1731 | None | None / None | None | None / None | None / FAIL |
| candidate-644db91013d39c0e3dd83c4f3322af0eb8cfa3bf38b37f82b54b131290ac4374 | None | None / None | None | None / None | None / FAIL |
| candidate-9f8fb0bdbc92be79580f5b6a7c6dcdb58490c18c9d5e633de3ceedc3c2b9e134 | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-60bcc36c0a704ab90698df2e558ca5ca07661b5a0329cc9cf96a9ef0f6aab4d1 | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-7266863046491d615757190cc2b3b574dfc540d49eddab56b69fdaaaa2aa0df6 | None | None / None | None | None / None | None / FAIL |
| candidate-65523cbca6b2216f86b665b88045037d64be5389e6190a9c710977d7f6be63a8 | None | None / None | None | None / None | None / FAIL |
| candidate-f9d09db4513b36d31341d923885125575a688866e9f53280b12818becc9f5b21 | None | None / None | None | None / None | None / FAIL |
| candidate-a416cbec58a0bcd4ed9defadb295a95974ad9d3f817ba22b48c178f4c9c192d9 | None | None / None | None | None / None | None / FAIL |
| candidate-27f15e027bfd6869453e457ae24e10a66a4360ab688df3cfdca5f091f01a7a7c | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-4ef011d2efe1972accea3b27c4eb9afb5ce2838dd0c8d31e942dfffcdb69eb8c | None | None / None | None | None / None | None / FAIL |
| candidate-94b08e23ac03be1c5ff52279f2ae9c127bcd8bce5b4a6fe1d03d4bd39a4a426b | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
| candidate-a275b88c7e801a0da7e1dd547a5f4c37c2328e7ebdc21ab560e1e3c3f859dbd6 | None | None / None | None | None / None | None / FAIL |
| candidate-ab38d93bad8c0005011c8db9854bbea44e521989211991ed550515cf695f94ed | None | None / None | None | None / None | None / FAIL |
| candidate-af059194b6929525c4c9845d5a4625cfeb13340ed6095aeb114e508f87074664 | None | None / None | None | None / None | None / FAIL |
| candidate-26124a3dc4b9284ac86e468953690e6c42b8339f4043ffa83709df8deaadb7d2 | None | None / None | None | None / None | None / FAIL |
| candidate-4d9dad849ded978cd454aaf6991dead8f533fee65519ac129e2cc5bd9aa5663a | None | None / None | None | None / None | None / FAIL |
| candidate-f98c5d9f9067de3a3ddf10f4e05c3980e5f94b3430e1f17c208f1872fa2fa67f | None | None / None | None | None / None | None / FAIL |
| candidate-cc84cdf5fca1ee7c6014517963c480061cfae79a73cd5c81931e4d2dcc72986a | None | None / None | None | None / None | None / FAIL |
