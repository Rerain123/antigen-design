# Local workflow engineering report

Scientific Gate: CLOSED; DEVELOPMENT_UNREVIEWED; NOT_DEPLOYED.

| Node | Branch | State | Reason | Origin | Detail |
|---|---|---|---|---|---|
| N04 | bepipred | succeeded |  | NEW_EXECUTION |  |
| N03 | blast | succeeded |  | NEW_EXECUTION |  |
| N12 | cheap0 | succeeded |  | NEW_EXECUTION |  |
| N16 | codon | skipped | EXPRESSION_HOST_NOT_PROVIDED |  |  |
| N11 | design_inputs | succeeded |  | NEW_EXECUTION |  |
| N10 | developability | succeeded |  | NEW_EXECUTION |  |
| N09 | domains | succeeded |  | NEW_EXECUTION |  |
| N06 | epitope_map | succeeded |  | NEW_EXECUTION |  |
| N11 | formal0 | succeeded |  | NEW_EXECUTION |  |
| N07 | glycosylation | succeeded |  | NEW_EXECUTION |  |
| N08 | homology | skipped | DATABASE_NOT_PROVIDED |  |  |
| N18 | local_delivery | succeeded |  | NEW_EXECUTION |  |
| N05 | netmhc | succeeded |  | NEW_EXECUTION |  |
| N01 | prediction | succeeded |  | NEW_EXECUTION |  |
| N11 | proposal0 | succeeded |  | NEW_EXECUTION |  |
| N11 | proposal1 | succeeded |  | NEW_EXECUTION |  |
| N12 | revision_design | succeeded | S28_ORIGINAL_PASS | INTERNAL_FACT |  |
| N12 | rx0_s12_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s14_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s1_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s2_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s3_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s7_af3 | succeeded |  | NEW_EXECUTION |  |
| N01 | structure | succeeded |  | NEW_EXECUTION |  |
| N02 | topology | succeeded |  | NEW_EXECUTION |  |
| N18 | wt_draft | succeeded |  | NEW_EXECUTION |  |
| N17 | wt_foldx | skipped | NO_COVERED_EXPLICIT_OPEN_SCAN_POSITION |  |  |
| N17 | wt_reference | succeeded |  | NEW_EXECUTION |  |
| N17 | wt_thermompnn | skipped | NO_COVERED_EXPLICIT_OPEN_SCAN_POSITION |  |  |
| N13 | z0_s12_bepipred | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s12_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s12_epitope_map | succeeded |  | NEW_EXECUTION |  |
| N14 | z0_s12_foldx | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s12_netmhc | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s12_structure | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s14_bepipred | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s14_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s14_epitope_map | succeeded |  | NEW_EXECUTION |  |
| N14 | z0_s14_foldx | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s14_netmhc | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s14_structure | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s1_bepipred | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s1_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s1_epitope_map | succeeded |  | NEW_EXECUTION |  |
| N14 | z0_s1_foldx | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s1_netmhc | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s1_structure | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s2_bepipred | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s2_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s2_epitope_map | succeeded |  | NEW_EXECUTION |  |
| N14 | z0_s2_foldx | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s2_netmhc | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s2_structure | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s3_bepipred | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s3_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s3_epitope_map | succeeded |  | NEW_EXECUTION |  |
| N14 | z0_s3_foldx | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s3_netmhc | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s3_structure | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s7_bepipred | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s7_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s7_epitope_map | succeeded |  | NEW_EXECUTION |  |
| N14 | z0_s7_foldx | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s7_netmhc | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s7_structure | succeeded |  | NEW_EXECUTION |  |

## Expert revision / engineering facts

Contract: t01-core-20260929-v1
Formal acceptance: NOT_ASSESSED
Proposals are nomination-only; full sequences, provenance and task budgets are in workflow.json.

| Candidate | Mutations | Disposition | S28 | FoldX execution / mean / valid repeats | Acceptance |
|---|---|---|---|---|---|
| candidate-57b80b76100605bfed08458553574056b73cae7fafb137ba84891eb54eb76f50 | 16 | FORMAL_POOL | PASS | SUCCEEDED / 0.4398126 / 5 | NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | 16 | FORMAL_POOL | PASS | SUCCEEDED / 0.48804420000000004 / 5 | NOT_ASSESSED |
| candidate-1e1b6e88b6374280e0f7f91e49e45796c006cf7aa0ff08762eb1278689df0cf8 | 15 | FORMAL_POOL | PASS | SUCCEEDED / -0.2257798 / 5 | NOT_ASSESSED |
| candidate-1e1b6e88b6374280e0f7f91e49e45796c006cf7aa0ff08762eb1278689df0cf8 | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | 16 | FORMAL_POOL | PASS | SUCCEEDED / 0.197085 / 5 | NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-9238e6911f416a497fa9df7ee66b547cce8df34c66ff37e49ec21ac4f1ac8b2c | 16 | FORMAL_POOL | PASS | SUCCEEDED / 0.29024286 / 5 | NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-75b9ea18d0c9f7e440b4dd6a6ae3d0e3c7d1883e0f0c8c23bd9d7c1b5993b0af | 15 | FORMAL_POOL | PASS | SUCCEEDED / -0.02644412000000001 / 5 | NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |

v2 thresholds: pending_calibration. Provisional task acceptance: PASS
Scores are comparable only within the same dimension, mode and evidence group; no global rank.

| Candidate | Supplier | N13 / legacy L1 identity | L4 | Comparison before / after penalty | Acceptance score / provisional |
|---|---|---|---|---|---|
| candidate-57b80b76100605bfed08458553574056b73cae7fafb137ba84891eb54eb76f50 | primary | PASS / False | PASS | 0.525342889967368 / 0.425342889967368 | 0.40344045350333546 / PASS |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | primary | PASS / False | PASS | 0.5267145893215373 / 0.4267145893215373 | 0.40243275202153594 / PASS |
| candidate-1e1b6e88b6374280e0f7f91e49e45796c006cf7aa0ff08762eb1278689df0cf8 | primary | PASS / False | PASS | 0.5421954400364408 / 0.44219544003644085 | 0.44722245626650897 / PASS |
| candidate-1e1b6e88b6374280e0f7f91e49e45796c006cf7aa0ff08762eb1278689df0cf8 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | primary | PASS / False | PASS | 0.5254242422662524 / 0.4254242422662524 | 0.4155779587736632 / PASS |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-9238e6911f416a497fa9df7ee66b547cce8df34c66ff37e49ec21ac4f1ac8b2c | primary | PASS / False | PASS | 0.5226513397725565 / 0.42265133977255653 | 0.40816461233658063 / PASS |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-75b9ea18d0c9f7e440b4dd6a6ae3d0e3c7d1883e0f0c8c23bd9d7c1b5993b0af | primary | PASS / False | PASS | 0.5398397316528072 / 0.4398397316528072 | 0.4349119183904897 / PASS |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-b51c3d00a7550f0d2fe1d34a3d0cf7b470ec27c4b59e2e28a185cc56d1e950d0 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-126d2c66f4ca6b9e07df1930ba3f69453b1408f673e9fad35c3b486b750b7c56 | None | None / None | None | None / None | None / NOT_ASSESSED |
