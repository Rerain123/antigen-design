# 本地工程交付报告

结果：DESIGN_NOT_EXECUTED

N11 候选设计未执行；原因：NO_DESIGNABLE_POSITIONS；详情：全部位点固定；原生候选生成未执行，候选数为 0。科学资格状态单独判断。

开发未签收。不是正式 CandidateRecord 或 AgentCHandoff；不自动交接 Agent C。
WT SHA-256：d58ea5610520e1bc7410e2a6216b25a48c80583b72912d2c5c31d66ca567144c

## 变体结论

| 变体 | 结果 | 淘汰原因 |
|---|---|---|

最佳候选：无。候选设计未执行。正式排名与资格未开放。

## 来源与缺项

- variant_report: MISSING
- wt_draft: DEVELOPMENT_UNREVIEWED
- wt_reference: DEVELOPMENT_UNREVIEWED
- wt_draft/homology: UPSTREAM_MISSING
- wt_reference/design_audit: UPSTREAM_MISSING
- wt_reference/foldx: UPSTREAM_MISSING
- wt_reference/thermompnn: UPSTREAM_MISSING
- N10: PARTIAL_DEVELOPABILITY
- N10/aggregation: A3D_SPATIAL_CLUSTER_SCIENTIFIC_SIGNOFF_MISSING
- N10/ph_stability: STRUCTURE_MAPPING_SCIENTIFIC_SIGNOFF_MISSING
- N10/solubility: OI_025_CAMSOL_PARAMETERS_INCOMPLETE
- N10/stability_ddg: STABILITY_DDG_NOT_COMPUTED
- N10/tag_exposure: OUTPUT_INVALID
- N17: NO_NATIVE_SCAN_EXECUTED
- N16: DNA_NOT_PROVIDED
- delivery: OI_013_AGENT_C_INTERFACE_UNSIGNED
- delivery: OI_014_CANDIDATE_RECORD_MAPPING_UNSIGNED
- delivery: SCIENTIFIC_GATES_NOT_RELEASED
- N17/foldx: NO_COVERED_EXPLICIT_OPEN_SCAN_POSITION
- N17/thermompnn: NO_COVERED_EXPLICIT_OPEN_SCAN_POSITION
- N11: NO_DESIGNABLE_POSITIONS

方法、扫描范围、原始 ArtifactRef 和逐层缺项见 [机器报告](data.json)。
实际包内文件及 hash 见 [清单](manifest.json)。原始工具产物留在原运行根，包内保留登记引用。
