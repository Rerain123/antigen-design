# Local workflow engineering report

Scientific Gate: CLOSED; DEVELOPMENT_UNREVIEWED; NOT_DEPLOYED.

| Node | Branch | State | Reason | Origin | Detail |
|---|---|---|---|---|---|
| N04 | bepipred | succeeded |  | NEW_EXECUTION |  |
| N03 | blast | succeeded |  | NEW_EXECUTION |  |
| N12 | cheap0 | succeeded |  | NEW_EXECUTION |  |
| N16 | codon | skipped | EXPRESSION_HOST_NOT_PROVIDED |  |  |
| N11 | design_inputs | succeeded |  | NEW_EXECUTION |  |
| N10 | developability | succeeded |  | NEW_EXECUTION |  |
| N09 | domains | succeeded |  | NEW_EXECUTION |  |
| N06 | epitope_map | succeeded |  | NEW_EXECUTION |  |
| N11 | formal0 | succeeded |  | NEW_EXECUTION |  |
| N07 | glycosylation | succeeded |  | NEW_EXECUTION |  |
| N08 | homology | skipped | DATABASE_NOT_PROVIDED |  |  |
| N18 | local_delivery | succeeded |  | NEW_EXECUTION |  |
| N05 | netmhc | succeeded |  | NEW_EXECUTION |  |
| N01 | prediction | succeeded |  | NEW_EXECUTION |  |
| N11 | proposal0 | succeeded |  | NEW_EXECUTION |  |
| N11 | proposal1 | succeeded |  | NEW_EXECUTION |  |
| N12 | revision_design | succeeded | S28_ORIGINAL_PASS | INTERNAL_FACT |  |
| N12 | rx0_s10_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s10_esmfold2 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s11_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s11_esmfold2 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s13_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s13_esmfold2 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s14_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s14_esmfold2 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s15_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s15_esmfold2 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s1_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s1_esmfold2 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s21_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s21_esmfold2 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s3_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s3_esmfold2 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s4_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s4_esmfold2 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s8_af3 | succeeded |  | NEW_EXECUTION |  |
| N12 | rx0_s8_esmfold2 | succeeded |  | NEW_EXECUTION |  |
| N01 | structure | succeeded |  | NEW_EXECUTION |  |
| N02 | topology | succeeded |  | NEW_EXECUTION |  |
| N18 | wt_draft | succeeded |  | NEW_EXECUTION |  |
| N17 | wt_foldx | skipped | NO_COVERED_EXPLICIT_OPEN_SCAN_POSITION |  |  |
| N12 | wt_msa | succeeded |  | NEW_EXECUTION |  |
| N17 | wt_reference | succeeded |  | NEW_EXECUTION |  |
| N17 | wt_thermompnn | skipped | NO_COVERED_EXPLICIT_OPEN_SCAN_POSITION |  |  |
| N10 | z0_s10_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s10_structure | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s11_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s11_structure | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s13_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s13_structure | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s14_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s14_structure | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s15_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s15_structure | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s1_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s1_structure | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s21_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s21_structure | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s3_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s3_structure | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s4_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s4_structure | succeeded |  | NEW_EXECUTION |  |
| N10 | z0_s8_developability | succeeded |  | NEW_EXECUTION |  |
| N13 | z0_s8_structure | succeeded |  | NEW_EXECUTION |  |

## Expert revision / engineering facts

Contract: t01-core-20260929-v1
Formal acceptance: FAIL
Proposals are nomination-only; full sequences, provenance and task budgets are in workflow.json.

| Candidate | Mutations | Disposition | S28 | FoldX execution / mean / valid repeats | Acceptance |
|---|---|---|---|---|---|
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | 15 | FORMAL_POOL | PASS | NOT_RUN / None / 0 | FAIL |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-c079494fa998fd5c4f55b8f3c55156ac825f0b0be4de4855ab1fc21af8f3e23f | 15 | FORMAL_POOL | PASS | NOT_RUN / None / 0 | FAIL |
| candidate-c4e319b8eb3d7f28c43ea58ca17b0ca2ac49c45f00127951d2db80351cbcdbaa | 15 | FORMAL_POOL | PASS | NOT_RUN / None / 0 | FAIL |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-517ecc9ede2f380e9f4fffac6cce85511d03ea0ce4b4269a0028665442153679 | 16 | FORMAL_POOL | PASS | NOT_RUN / None / 0 | FAIL |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-bb924ff7c1c70afa16eb6cbaeff8c1d4e08703e130511b072330f79c013695b1 | 16 | FORMAL_POOL | PASS | NOT_RUN / None / 0 | FAIL |
| candidate-04e80aa408a7db1af82b16b99c952d68ff9bced37633622f8f67f7e43c0ec22d | 15 | FORMAL_POOL | PASS | NOT_RUN / None / 0 | FAIL |
| candidate-517ecc9ede2f380e9f4fffac6cce85511d03ea0ce4b4269a0028665442153679 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-b569195f6eafb1910078084ae3002eff8034bc535c492043f083341fe745c22c | 16 | FORMAL_POOL | PASS | NOT_RUN / None / 0 | FAIL |
| candidate-cace6adaf4c68f2098b104a9c953b79d74bb661113899635d92a1b09a42cad12 | 15 | FORMAL_POOL | PASS | NOT_RUN / None / 0 | FAIL |
| candidate-105c3c7c422848216a3bab44e8bacb4c0e7e9617091fe2e0a3e952889a06a0f1 | 16 | FORMAL_POOL | PASS | NOT_RUN / None / 0 | FAIL |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-517ecc9ede2f380e9f4fffac6cce85511d03ea0ce4b4269a0028665442153679 | 16 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-c079494fa998fd5c4f55b8f3c55156ac825f0b0be4de4855ab1fc21af8f3e23f | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-05e92d3d84d8edf0d056f44bda74dd42d563f6e457ca90ce78d971590612bf91 | 15 | FORMAL_POOL | PASS | NOT_RUN / None / 0 | FAIL |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |
| candidate-c079494fa998fd5c4f55b8f3c55156ac825f0b0be4de4855ab1fc21af8f3e23f | 15 | DUPLICATE | NOT_ASSESSED | NOT_RUN / None / 0 | NOT_ASSESSED |

v2 thresholds: pending_calibration. Provisional task acceptance: FAIL
Scores are comparable only within the same dimension, mode and evidence group; no global rank.

| Candidate | Supplier | N13 / legacy L1 identity | L4 | Comparison before / after penalty | Acceptance score / provisional |
|---|---|---|---|---|---|
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | primary | FAIL / None | NOT_ASSESSED | None / None | None / FAIL |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-c079494fa998fd5c4f55b8f3c55156ac825f0b0be4de4855ab1fc21af8f3e23f | primary | FAIL / None | NOT_ASSESSED | None / None | None / FAIL |
| candidate-c4e319b8eb3d7f28c43ea58ca17b0ca2ac49c45f00127951d2db80351cbcdbaa | primary | FAIL / None | NOT_ASSESSED | None / None | None / FAIL |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-517ecc9ede2f380e9f4fffac6cce85511d03ea0ce4b4269a0028665442153679 | primary | FAIL / None | NOT_ASSESSED | None / None | None / FAIL |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-bb924ff7c1c70afa16eb6cbaeff8c1d4e08703e130511b072330f79c013695b1 | primary | FAIL / None | NOT_ASSESSED | None / None | None / FAIL |
| candidate-04e80aa408a7db1af82b16b99c952d68ff9bced37633622f8f67f7e43c0ec22d | primary | FAIL / None | NOT_ASSESSED | None / None | None / FAIL |
| candidate-517ecc9ede2f380e9f4fffac6cce85511d03ea0ce4b4269a0028665442153679 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-b569195f6eafb1910078084ae3002eff8034bc535c492043f083341fe745c22c | primary | FAIL / None | NOT_ASSESSED | None / None | None / FAIL |
| candidate-cace6adaf4c68f2098b104a9c953b79d74bb661113899635d92a1b09a42cad12 | primary | FAIL / None | NOT_ASSESSED | None / None | None / FAIL |
| candidate-105c3c7c422848216a3bab44e8bacb4c0e7e9617091fe2e0a3e952889a06a0f1 | primary | FAIL / None | NOT_ASSESSED | None / None | None / FAIL |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-517ecc9ede2f380e9f4fffac6cce85511d03ea0ce4b4269a0028665442153679 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-c079494fa998fd5c4f55b8f3c55156ac825f0b0be4de4855ab1fc21af8f3e23f | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-05e92d3d84d8edf0d056f44bda74dd42d563f6e457ca90ce78d971590612bf91 | primary | FAIL / None | NOT_ASSESSED | None / None | None / FAIL |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-680de1e3350c33dd60d525f3620cf31a067f2c03f1bea6219644ee6389c5b528 | None | None / None | None | None / None | None / NOT_ASSESSED |
| candidate-c079494fa998fd5c4f55b8f3c55156ac825f0b0be4de4855ab1fc21af8f3e23f | None | None / None | None | None / None | None / NOT_ASSESSED |
