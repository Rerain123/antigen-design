"""C44 defined intrinsic terms; unresolved parameters never become a score.

The expert asset remains read-only. Pattern counting and random calibration
must be settled before Eq.2 normalization / Eq.9 can be published.
"""
import math

from ...common import REPO, decode, ensure, sha

ASSET = REPO / '工作流设计/01-业务依据/抗原智能体_v10.5_修订版_20260902/camsol_params.json'
ASSET_SHA256 = 'fb135655bf2bf326db5c94a3c914a6a85eb2dd0de1bf6aa909ca2f8f27f629f4'


def parameters():
    raw = ASSET.read_bytes()
    ensure(sha(raw) == ASSET_SHA256 and
           ASSET.with_suffix('.json.sha256').read_text(encoding='utf8').strip() == ASSET_SHA256,
           'HASH_MISMATCH', 'C44 expert parameter asset hash mismatch')
    return decode(raw)


def intrinsic_terms(sequence, params):
    """Eq.1, boundary-truncated smooth term and Eq.3, before pattern correction."""
    scales = params['amino_acid_scales']; a = params['linear_coefficients']
    ensure(isinstance(sequence, str) and sequence and all(aa in scales for aa in sequence),
           'INVALID_REQUEST', 'C44 requires a nonempty AA20 sequence')
    raw = [math.fsum((a['a_H'] * scales[aa]['hydrophobicity'],
                     a['a_C'] * scales[aa]['charge'],
                     a['a_alpha'] * scales[aa]['alpha'],
                     a['a_beta'] * scales[aa]['beta'])) for aa in sequence]
    smooth = [math.fsum(raw[max(0, i-3):i+4]) / len(raw[max(0, i-3):i+4])
              for i in range(len(sequence))]
    gatekeeper = [math.fsum(math.exp(-abs(j-i)**4/200) * scales[sequence[j]]['charge']
                           for j in range(max(0, i-5), min(len(sequence), i+6)))
                  for i in range(len(sequence))]
    return dict(eq1_raw=raw,eq2_smoothing_term=smooth,eq3_gatekeeper=gatekeeper,
                eq2_complete=None,normalized_profile=None,
                qualification='INTERMEDIATE_ONLY_NOT_SOLUBILITY')


def assess(sequence, target_ph=None):
    params = parameters()
    # No fallback pKa, unapproved pattern convention or synthetic calibration.
    terms = intrinsic_terms(sequence, params) if target_ph is None else None
    blocked = ['OI_025_ALTERNATING_PATTERN_COUNT_UNRESOLVED',
               'OI_025_ROSEMAN_ASSET_NOT_REGISTERED',
               'OI_025_RANDOM_NORMALIZATION_NOT_CALIBRATED']
    return dict(status='unavailable',reliable=False,
                reason_code='OI_025_CAMSOL_PARAMETERS_INCOMPLETE',
                global_score=None,per_residue=None,classification=None,insoluble_regions=None,
                mode='intrinsic' if target_ph is None else 'ph_mvp',
                ph_used='neutral' if target_ph is None else target_ph,
                tool='CamSol-reimpl(C44)',blocked_dependencies=blocked,
                intermediate_terms=terms,parameter_sha256=ASSET_SHA256,
                method_summary=dict(source='C44 v10.5 §2b',network=False,
                    random_sequence_length=200,random_sequence_count=100000,
                    official_numeric_comparison='NOT_PERFORMED'),
                scientific_consumption=False)
