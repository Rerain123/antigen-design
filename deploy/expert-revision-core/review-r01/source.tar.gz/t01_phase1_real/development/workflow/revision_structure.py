"""Revision structure allocation and model roles, separate from legacy R-04.

Policy absence blocks model consumption; the schedule and multi-engine
reservations remain executable and testable without declaring a science policy.
"""
from ...common import ensure
from .revision_contract import check,diagnostic
from .revision_sampling import select_structure
from .revision_budget import reserve


def route(length,count):
    ensure(type(length) is int and length>0 and type(count) is int and 0<=count<=length,
           'OUTPUT_INVALID','Invalid WT mutation count')
    return ['af3'] if count<=5 else ['af3','esmfold2'] if count*10<=length else ['esmfold2']


def plan(records,scored,ledger,cfg,policy):
    used={o for r in ledger['reservations'].values() if r['stage']=='structure' for o in r['objects']}
    remaining=max(0,cfg['structure_eval_max']-len(used))
    selected=select_structure([r for r in records if r['content_hash'] not in used],scored,remaining)
    result=[]
    for row in records:
        reasons=[];engines=[]
        if row['constraint_check']['check_status']=='FAIL':reasons=['EARLY_HARD_FAIL']
        elif row['disposition']!='FORMAL_POOL':reasons=[row['disposition']]
        elif row['candidate_id'] not in selected:reasons=['not_selected_for_structure_budget' if remaining==0 else 'CHEAP_CHECKS_NOT_PASSED']
        elif not isinstance(policy,dict) or not policy.get('required_set_id') or not policy.get('required_check_ids') or not policy.get('model_roles'):
            reasons=['configuration_incomplete']
        else:
            engines=route(len(row['sequence']),len(row['mutations']))
            if any(policy['model_roles'].get(e) not in ('mandatory','advisory') for e in engines):
                engines=[];reasons=['configuration_incomplete']
        result.append(dict(candidate_id=row['candidate_id'],content_hash=row['content_hash'],engines=engines,
            **check('NOT_ASSESSED',*reasons,execution='NOT_RUN')))
    return result


def reserve_engines(ledger,cfg,record,round_id):
    """Atomic all-engine allocation: failed second reservation spends nothing."""
    import copy
    tentative=copy.deepcopy(ledger)
    for engine in record['engines']:
        if not reserve(tentative,cfg,f'{round_id}:{record["candidate_id"]}:{engine}',
                       'structure',[record['content_hash']]):return False
    ledger.clear();ledger.update(tentative)
    return True
