import logging
import sys

from biolib import utils
from biolib._internal import cli
from biolib.biolib_logging import logger, logger_no_user_data
from biolib.cli import auth, data_record, file_system, index, init, lfs, push, run, runtime, sdk


@cli.version_option(version=utils.BIOLIB_PACKAGE_VERSION, prog_name='pybiolib')
@cli.group(name='cli', context_settings=dict(help_option_names=['-h', '--help']))
def cli_entrypoint() -> None:
    logger_no_user_data.debug(f'pybiolib {utils.BIOLIB_PACKAGE_VERSION}')
    logger_no_user_data.debug(f'Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')
    utils.STREAM_STDOUT = True

    # set more restrictive default log level for CLI
    logger.configure(default_log_level=logging.WARNING)
    logger_no_user_data.configure(default_log_level=logging.WARNING)


cli_entrypoint.add_command(auth.login)
cli_entrypoint.add_command(auth.logout)
cli_entrypoint.add_command(auth.whoami)
cli_entrypoint.add_command(init.init)
cli_entrypoint.add_command(lfs.lfs)
cli_entrypoint.add_command(push.push)
cli_entrypoint.add_command(run.run)
cli_entrypoint.add_command(runtime.runtime)
cli_entrypoint.add_command(data_record.data_record)
cli_entrypoint.add_command(index.index)
cli_entrypoint.add_command(sdk.sdk)
cli_entrypoint.add_command(file_system.file_system)

# allow this script to be called without poetry in dev e.g. by an IDE debugger
if utils.IS_DEV and __name__ == '__main__':
    cli_entrypoint()
