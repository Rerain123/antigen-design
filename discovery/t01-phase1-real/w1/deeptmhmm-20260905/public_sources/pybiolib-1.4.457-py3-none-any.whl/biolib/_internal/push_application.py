import json
import os
import re
import sys
import time
from pathlib import Path

from biolib import api, utils
from biolib._internal import docker, oci
from biolib._internal.data_record.push_data import (
    push_data_path,
    validate_data_path_and_get_files_and_size_of_directory,
)
from biolib._internal.docker import DockerStatusUpdate
from biolib._internal.errors import AuthenticationError
from biolib._internal.file_utils import get_files_and_size_of_directory, get_iterable_zip_stream
from biolib._internal.progress import Progress
from biolib._internal.yaml_parser import YAMLParseError
from biolib._internal.yaml_parser import safe_load as yaml_safe_load
from biolib._runtime.runtime import Runtime
from biolib._shared.types import PushResponseDict
from biolib._shared.types.typing import Dict, Iterable, List, Optional, Set, Union
from biolib._shared.utils import parse_resource_uri
from biolib.biolib_api_client import BiolibApiClient
from biolib.biolib_api_client.biolib_app_api import BiolibAppApi
from biolib.biolib_errors import BioLibError
from biolib.biolib_logging import logger

REGEX_MARKDOWN_INLINE_IMAGE = re.compile(r'!\[(?P<alt>.*?)\]\((?P<src>[^\s)]+)\)')


def _raise_if_docker_status_update_is_error(update: DockerStatusUpdate, action: str) -> None:
    if 'error' not in update and 'errorDetail' not in update:
        return
    error_message = update.get('error') or update.get('errorDetail', {}).get('message') or 'Unknown error'
    raise BioLibError(f'{action} Docker image failed: {error_message}')


def process_docker_status_updates(status_updates: Iterable[DockerStatusUpdate], action: str) -> None:
    if sys.stdout.isatty():
        _process_docker_status_updates_with_progress_bar(status_updates, action)
    else:
        _process_docker_status_updates_with_logging(status_updates, action)


def _process_docker_status_updates_with_progress_bar(status_updates: Iterable[DockerStatusUpdate], action: str) -> None:
    with Progress() as progress:
        layer_id_to_task_id = {}
        overall_task_id = progress.add_task(description=f'[bold blue]{action} Docker image', total=None)

        for update in status_updates:
            _raise_if_docker_status_update_is_error(update, action)
            if 'progressDetail' in update and 'id' in update:
                layer_id = update['id']
                progress_detail = update['progressDetail']

                if layer_id not in layer_id_to_task_id:
                    layer_id_to_task_id[layer_id] = progress.add_task(description=f'[cyan]{action} layer {layer_id}')

                if progress_detail and 'current' in progress_detail and 'total' in progress_detail:
                    progress.update(
                        task_id=layer_id_to_task_id[layer_id],
                        completed=progress_detail['current'],
                        total=progress_detail['total'],
                    )
                elif update['status'] == 'Layer already exists':
                    progress.update(
                        completed=100,
                        task_id=layer_id_to_task_id[layer_id],
                        total=100,
                    )
            elif 'status' in update and 'id' in update:
                layer_id = update['id']
                status = update['status']

                if layer_id not in layer_id_to_task_id:
                    layer_id_to_task_id[layer_id] = progress.add_task(description=f'[cyan]{action} layer {layer_id}')

                if status in ['Preparing', 'Waiting']:
                    progress.update(
                        task_id=layer_id_to_task_id[layer_id], description=f'[yellow]{status} layer {layer_id}'
                    )
                elif status in ['Pushing', 'Uploading']:
                    progress.update(
                        task_id=layer_id_to_task_id[layer_id], description=f'[cyan]{status} layer {layer_id}'
                    )
                elif status in ['Pushed', 'Uploaded']:
                    progress.update(
                        task_id=layer_id_to_task_id[layer_id],
                        description=f'[green]{status} layer {layer_id}',
                        completed=100,
                        total=100,
                    )
                elif status == 'Layer already exists':
                    progress.update(
                        task_id=layer_id_to_task_id[layer_id],
                        description=f'[green]{status} - layer {layer_id}',
                        completed=100,
                        total=100,
                    )
            elif 'status' in update and update['status']:
                status = update['status']
                if status not in ['Preparing', 'Pushing', 'Pushed', 'Waiting', 'Layer already exists']:
                    progress.update(task_id=overall_task_id, description=f'[bold blue]{action} Docker image - {status}')
            elif 'status' not in update and 'progressDetail' not in update:
                print(update)

        # Mark any layers that never received progress totals as complete
        for task_id in layer_id_to_task_id.values():
            progress.update(task_id=task_id, completed=100, total=100)


def _process_docker_status_updates_with_logging(status_updates: Iterable[DockerStatusUpdate], action: str) -> None:
    layer_progress: Dict[str, float] = {}
    layer_status: Dict[str, str] = {}
    layer_details: Dict[str, Dict[str, int]] = {}
    layer_bytes_at_last_log: Dict[str, int] = {}
    last_log_time = time.time()

    logger.info(f'{action} Docker image...')

    for update in status_updates:
        _raise_if_docker_status_update_is_error(update, action)
        current_time = time.time()

        if 'progressDetail' in update and 'id' in update:
            layer_id = update['id']
            progress_detail = update['progressDetail']

            if progress_detail and 'current' in progress_detail and 'total' in progress_detail:
                current = progress_detail['current']
                total = progress_detail['total']
                percentage = (current / total * 100) if total > 0 else 0
                layer_progress[layer_id] = percentage
                layer_status[layer_id] = f'{action.lower()}'
                layer_details[layer_id] = {'current': current, 'total': total}
            elif update.get('status') == 'Layer already exists':
                layer_progress[layer_id] = 100
                layer_status[layer_id] = 'already exists'

        elif 'status' in update and 'id' in update:
            layer_id = update['id']
            status = update['status']
            layer_status[layer_id] = status.lower()

            if status in ['Pushed', 'Uploaded'] or status == 'Layer already exists':
                layer_progress[layer_id] = 100

        elif 'status' in update and update['status']:
            status = update['status']
            if status not in ['Preparing', 'Pushing', 'Pushed', 'Waiting', 'Layer already exists']:
                logger.info(f'{action} Docker image - {status}')

        if current_time - last_log_time >= 10.0:
            _log_progress_summary(
                action,
                layer_progress,
                layer_status,
                layer_details,
                layer_bytes_at_last_log,
                current_time - last_log_time,
            )
            layer_bytes_at_last_log = {lid: details['current'] for lid, details in layer_details.items()}
            last_log_time = current_time

    _log_progress_summary(
        action, layer_progress, layer_status, layer_details, layer_bytes_at_last_log, time.time() - last_log_time
    )
    if action == 'Pushing':
        logger.info('Pushing final image manifest...')
    logger.info(f'{action} Docker image completed')


def _log_progress_summary(
    action: str,
    layer_progress: Dict[str, float],
    layer_status: Dict[str, str],
    layer_details: Dict[str, Dict[str, int]],
    layer_bytes_at_last_log: Dict[str, int],
    time_delta: float,
) -> None:
    if not layer_progress and not layer_status:
        return

    completed_layers = sum(1 for progress in layer_progress.values() if progress >= 100)
    total_layers = len(layer_progress) if layer_progress else len(layer_status)

    if total_layers > 0:
        overall_percentage = completed_layers / total_layers * 100
        logger.info(
            f'{action} progress: {completed_layers}/{total_layers} layers completed ({overall_percentage:.1f}%)'
        )

    active_layers = [
        layer_id
        for layer_id, status in layer_status.items()
        if status in ['preparing', 'waiting', 'pushing', 'uploading'] and layer_progress.get(layer_id, 0) < 100
    ]

    if active_layers and layer_details:
        total_bytes_transferred = 0
        layer_info_parts = []

        for layer_id in active_layers[:5]:
            if layer_id in layer_details:
                details = layer_details[layer_id]
                current = details['current']
                total = details['total']
                percentage = layer_progress.get(layer_id, 0)

                bytes_since_last = current - layer_bytes_at_last_log.get(layer_id, 0)
                total_bytes_transferred += bytes_since_last

                current_mb = current / (1024 * 1024)
                total_mb = total / (1024 * 1024)
                layer_info_parts.append(f'{layer_id}: {current_mb:.1f}/{total_mb:.1f} MB ({percentage:.1f}%)')

        speed_info = ''
        if time_delta > 0 and total_bytes_transferred > 0:
            speed_mbps = (total_bytes_transferred / (1024 * 1024)) / time_delta
            speed_info = f' @ {speed_mbps:.2f} MB/s'

        more_layers_info = ''
        if len(active_layers) > 5:
            more_layers_info = f' (+ {len(active_layers) - 5} more)'

        if layer_info_parts:
            logger.info(f'Active layers: {", ".join(layer_info_parts)}{speed_info}{more_layers_info}')
    elif active_layers:
        logger.info(f'Active layers: {", ".join(active_layers[:5])}{"..." if len(active_layers) > 5 else ""}')


def push_application(
    app_uri: str,
    app_path: str,
    app_version_to_copy_images_from: Optional[str],
    set_as_active: bool,
    set_as_published: bool,
    dry_run: bool = False,
) -> Optional[PushResponseDict]:
    app_uri = app_uri.rstrip('/')
    parsed_uri = parse_resource_uri(app_uri)
    resource_name = parsed_uri['resource_name']

    app_uri_prefix = f'@{parsed_uri["resource_prefix"]}/' if parsed_uri['resource_prefix'] is not None else ''
    app_uri_without_suffix = f'{app_uri_prefix}{parsed_uri["account_handle_normalized"]}/{resource_name}'
    app_uri_to_fetch = app_uri_without_suffix

    version = parsed_uri['version']
    semantic_version = f'{version["major"]}.{version["minor"]}.{version["patch"]}' if version else None

    app_path_absolute = Path(app_path).resolve()

    api_client = BiolibApiClient.get()
    if not api_client.is_signed_in and not Runtime.check_is_environment_biolib_app():
        github_repository = os.getenv('GITHUB_REPOSITORY')
        if github_repository and not api_client.resource_deploy_key:
            github_secrets_url = f'https://github.com/{github_repository}/settings/secrets/actions/new'
            raise AuthenticationError(
                'You must be authenticated to push an application.\n'
                'Please set the environment variable "BIOLIB_TOKEN=[your_deploy_token]"\n'
                f'You can get a deploy key at: {api_client.base_url}/{app_uri_to_fetch}/settings/keys/\n'
                f'Then add it to your GitHub repository at: {github_secrets_url}'
            )
        else:
            raise AuthenticationError(
                'You must be authenticated to push an application.\n'
                'Please set the environment variable "BIOLIB_TOKEN=[your_deploy_token]"\n'
                f'You can get a deploy key at: {api_client.base_url}/{app_uri_to_fetch}/settings/keys/'
            )

    # prepare zip file
    config_yml_path = app_path_absolute.joinpath('.biolib/config.yml')
    if not config_yml_path.is_file():
        raise BioLibError('The file .biolib/config.yml was not found in the application directory')

    zip_filters: Set[str] = set()
    zip_filters.add('.biolib/config.yml')

    input_files_maps_to_root = False
    assets_path: Optional[Path] = None
    description_extra_files: Dict[str, str] = {}
    source_path_to_archive_name: Dict[str, str] = {}
    image_counter = 0
    modified_description = ''
    try:
        with open(config_yml_path) as config_yml_file:
            try:
                config = json.loads(json.dumps(yaml_safe_load(config_yml_file.read())))
            except YAMLParseError as error:
                raise BioLibError(
                    f'The .biolib/config.yml file contains invalid YAML. Original error: {error}'
                ) from error
            except (TypeError, ValueError) as error:
                raise BioLibError(
                    f'The .biolib/config.yml file contains data types that are not supported '
                    f'(must be JSON-serializable). Please ensure only standard JSON types '
                    f'(str, int, float, bool, list, dict, null) are used. Original error: {error}'
                ) from error

        if 'app_data' in config and 'assets' not in config:
            config['assets'] = config.pop('app_data')
        elif 'app_data' in config and 'assets' in config:
            raise BioLibError(
                'In .biolib/config.yml you cannot specify both "assets" and "app_data" fields. Please use only one.'
            )

        assets = config.get('assets')
        if assets:
            field_name = 'assets' if 'assets' in config else 'app_data'
            if not isinstance(assets, str):
                raise BioLibError(
                    f'In .biolib/config.yml the value of "{field_name}" must be a string but got {type(assets)}'
                )

            assets_path = app_path_absolute.joinpath(assets).resolve()
            if not assets_path.is_dir():
                raise BioLibError(
                    f'In .biolib/config.yml the value of "{field_name}" must be a path to a directory '
                    'in the application directory'
                )

        license_file_relative_path = config.get('license_file', 'LICENSE')
        if app_path_absolute.joinpath(license_file_relative_path).is_file():
            zip_filters.add(license_file_relative_path)

        description_file_relative_path = config.get('description_file', 'README.md')
        description_file_absolute_path = app_path_absolute.joinpath(description_file_relative_path)
        if not description_file_absolute_path.is_file():
            raise BioLibError(f'Could not find {description_file_relative_path}')

        zip_filters.add(description_file_relative_path)
        with open(description_file_absolute_path) as description_file:
            description_file_content = description_file.read()

        def _replace_local_image_path(match: re.Match) -> str:
            nonlocal image_counter
            src: str = match.group('src')
            if (
                src.startswith(('http://', 'https://', 'assets://', '/'))
                or '../' in src
                or not app_path_absolute.joinpath(src).is_file()
            ):
                return str(match.group(0))

            source_path = str(app_path_absolute / src)
            if source_path in source_path_to_archive_name:
                archive_name = source_path_to_archive_name[source_path]
            else:
                image_counter += 1
                filename = Path(source_path).name
                archive_name = f'.biolib/description/{image_counter}_{filename}'
                source_path_to_archive_name[source_path] = archive_name
                description_extra_files[archive_name] = source_path
            return f'![{match.group("alt")}](assets://{archive_name})'

        modified_description = re.sub(REGEX_MARKDOWN_INLINE_IMAGE, _replace_local_image_path, description_file_content)

        for _, module in config['modules'].items():
            if module.get('source_files'):
                zip_filters.add('*')

            for mapping in module.get('input_files', []):
                mapping_parts = mapping.split(' ')
                if len(mapping_parts) == 3 and mapping_parts[2] == '/':
                    input_files_maps_to_root = True

    except BioLibError as error:
        raise error from None

    except Exception as error:
        raise BioLibError('Failed to parse the .biolib/config.yml file') from error

    if input_files_maps_to_root:
        logger.error(
            'Error: In your config.yml some module maps input files to "/" (root). '
            'This is potentially an unsafe operation as it allows the user to '
            'overwrite system executables in the module.'
        )
        exit(1)

    files_in_app_dir, _ = get_files_and_size_of_directory(directory=str(app_path_absolute))
    files_to_zip: Set[str] = set()

    for file_path in files_in_app_dir:
        for pattern in zip_filters:
            if pattern == '*' or pattern == file_path:
                files_to_zip.add(file_path)
                break

    original_directory = os.getcwd()
    os.chdir(app_path_absolute.parent)
    files_with_app_dir_prefixed: List[Union[str, Dict[str, bytes]]] = []
    for path in files_to_zip:
        prefixed_path = f'{app_path_absolute.stem}/{path}'
        if path == description_file_relative_path:
            files_with_app_dir_prefixed.append({prefixed_path: modified_description.encode('utf-8')})
        else:
            files_with_app_dir_prefixed.append(prefixed_path)

    # Workaround as backend currently expects directory objects for root level and .biolib directory
    files_with_app_dir_prefixed.append(f'{app_path_absolute.stem}/')
    files_with_app_dir_prefixed.append(f'{app_path_absolute.stem}/.biolib/')

    byte_iterator = get_iterable_zip_stream(files_with_app_dir_prefixed, chunk_size=50_000_000)
    source_files_zip_bytes = b''.join(byte_iterator)
    os.chdir(original_directory)

    if app_version_to_copy_images_from and app_version_to_copy_images_from != 'active':
        # Get app with `app_version_to_copy_images_from` in app_uri_to_fetch to get the app version public id.
        app_uri_to_fetch += f':{app_version_to_copy_images_from}'

    app_response = BiolibAppApi.get_by_uri(app_uri_to_fetch)
    app = app_response['app']

    if dry_run:
        logger.info('Successfully completed dry-run. No new version was pushed.')
        return None

    if Runtime.check_is_environment_biolib_app():
        for module_name, module_config in config.get('modules', {}).items():
            image = module_config.get('image', '')
            if image and not image.startswith('local-oci-path://'):
                raise BioLibError(
                    f'Module {module_name} uses image type "{image.split("://")[0]}://" '
                    f'which requires Docker and is not supported when pushing from within a BioLib app. '
                    f'Please use "local-oci-path://" instead.'
                )

    new_app_version_json = BiolibAppApi.push_app_version(
        semantic_version=semantic_version,
        app_id=app['public_id'],
        app_name=app['name'],
        author=app['account_handle'],
        set_as_active=False,
        zip_binary=source_files_zip_bytes,
        app_version_id_to_copy_images_from=app_response['app_version']['public_id']
        if app_version_to_copy_images_from
        else None,
    )

    assets_files_to_zip: List[Union[str, Dict[str, bytes]]] = []
    assets_size_in_bytes = 0
    if assets_path:
        asset_file_paths, assets_size_in_bytes = validate_data_path_and_get_files_and_size_of_directory(
            data_path=str(assets_path),
        )
        assets_files_to_zip.extend(asset_file_paths)

    if assets_path or description_extra_files:
        extra_files_size = 0
        for archive_name, source_path in description_extra_files.items():
            with open(source_path, 'rb') as file:
                file_bytes = file.read()
            assets_files_to_zip.append({archive_name: file_bytes})
            extra_files_size += len(file_bytes)

        push_data_path(
            resource_version_uuid=new_app_version_json['public_id'],
            data_path=str(assets_path) if assets_path else None,
            data_size_in_bytes=assets_size_in_bytes + extra_files_size,
            files_to_zip=assets_files_to_zip,
        )

    #  Don't push docker images if copying from another app version
    docker_tags = new_app_version_json.get('docker_tags', {})
    if not app_version_to_copy_images_from and docker_tags:
        logger.info('Found docker images to push.')
        registry_username = 'biolib'
        registry_password = (
            ''  # Note: auth is added by remote host proxy in biolib-compute-node
            if Runtime.check_is_environment_biolib_app()
            else (api_client.resource_deploy_key or f'{api_client.access_token},')
        )

        for module_name, repo_and_tag in docker_tags.items():
            docker_image_definition = config['modules'][module_name]['image']
            repo, tag = repo_and_tag.split(':')

            if docker_image_definition.startswith('local-oci-path://'):
                oci_relative_path = docker_image_definition.replace('local-oci-path://', '', 1)
                oci_path = str((app_path_absolute / oci_relative_path).resolve())
                if not os.path.isfile(os.path.join(oci_path, 'index.json')):
                    raise BioLibError(f'OCI image not found or invalid (missing index.json): {oci_path}')

                logger.info(f'Pushing OCI image from {oci_path} for module {module_name}.')
                try:
                    oci.push_oci_image_to_registry(
                        oci_path=oci_path,
                        repository=repo,
                        tag=tag,
                        username=registry_username,
                        password=registry_password,
                    )
                except Exception as exception:
                    raise BioLibError(f'Failed to push OCI image for module {module_name}: {exception}') from exception
                continue

            docker.check_docker_running()

            if docker_image_definition.startswith('dockerhub://'):
                docker_image_name = docker_image_definition.replace('dockerhub://', 'docker.io/', 1)
                logger.info(f'Pulling image {docker_image_name} defined on module {module_name} from Dockerhub.')
                dockerhub_repo, dockerhub_tag = docker_image_name.split(':')
                pull_status_updates = docker.pull_image(
                    repository=dockerhub_repo,
                    tag=dockerhub_tag,
                    platform='linux/amd64',
                )

                process_docker_status_updates(pull_status_updates, action='Pulling')

            elif docker_image_definition.startswith('local-docker://'):
                docker_image_name = docker_image_definition.replace('local-docker://', '', 1)

            else:
                raise BioLibError(f'Unsupported image type for module {module_name}: {docker_image_definition}')

            try:
                logger.info(f'Trying to push image {docker_image_name} defined on module {module_name}.')
                image_info = docker.get_image_info(docker_image_name)
                architecture = image_info.get('Architecture')
                if architecture != 'amd64':
                    print(f"Error: '{docker_image_name}' is compiled for {architecture}, expected x86 (amd64).")
                    print('If you are on an ARM processor, try passing --platform linux/amd64 to docker build.')
                    exit(1)
                absolute_repo_uri = f'{utils.BIOLIB_SITE_HOSTNAME}/{repo}'
                docker.tag_image(docker_image_name, absolute_repo_uri, tag)

                push_status_updates = docker.push_image(
                    repository=absolute_repo_uri,
                    tag=tag,
                    auth_config={
                        'username': registry_username,
                        # For legacy reasons access token is sent with trailing comma ','
                        'password': registry_password,
                    },
                )

                process_docker_status_updates(push_status_updates, action='Pushing')

            except Exception as exception:
                logger.exception(f'Failed to tag and push image {docker_image_name}')
                raise BioLibError(f'Failed to tag and push image {docker_image_name}: {exception}') from exception

            image_size = image_info.get('Size', 0)
            size_str = f'{image_size / 1024**3:.1f} GB' if image_size >= 1024**3 else f'{image_size / 1024**2:.0f} MB'
            logger.info(f'Successfully pushed {docker_image_name} ({size_str})')

    app_version_uuid = new_app_version_json['public_id']
    complete_push_data: Dict[str, Union[bool, str]] = {
        'set_as_active': set_as_active,
        'set_as_published': set_as_published,
    }
    if parsed_uri['tag']:
        complete_push_data['tag'] = parsed_uri['tag']
    api.client.post(
        path=f'/app-versions/{app_version_uuid}/complete-push/',
        data=complete_push_data,
    )

    sematic_version = f'{new_app_version_json["major"]}.{new_app_version_json["minor"]}.{new_app_version_json["patch"]}'
    version_name = 'development ' if not set_as_published else ''
    logger.info(f'Successfully pushed new {version_name}version {sematic_version} of {app_uri}.')

    return {'app_uri': app_uri_without_suffix, 'sematic_version': sematic_version}
