import os
import sys
import traceback
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from biolib.biolib_logging import logger

from .types import BOOL, INT, UNPROCESSED, CliType


class _Option:
    def __init__(  # pylint: disable=redefined-builtin
        self,
        param_decls: Tuple[str, ...],
        is_flag: bool,
        default: Any,
        required: bool,
        type: Any,
        help: Optional[str],
        hidden: bool,
        explicit_name: Optional[str] = None,
    ):
        self.is_flag = is_flag
        self.default = default
        self.required = required
        self.type = type
        self.help = help
        self.hidden = hidden

        self.long_name = ''
        self.short_name: Optional[str] = None
        for decl in param_decls:
            if decl.startswith('--'):
                self.long_name = decl
            elif decl.startswith('-') and len(decl) == 2:
                self.short_name = decl

        if not self.long_name:
            self.long_name = param_decls[0]

        if explicit_name:
            self.param_name = explicit_name
        else:
            self.param_name = self.long_name.lstrip('-').replace('-', '_')

    def matches(self, arg: str) -> bool:
        key = arg.split('=', 1)[0] if '=' in arg and not self.is_flag else arg
        return key == self.long_name or (self.short_name is not None and key == self.short_name)

    def get_display_name(self) -> str:
        parts = []
        if self.short_name and self.short_name != self.long_name:
            parts.append(self.short_name)
        parts.append(self.long_name)
        return ', '.join(parts)


class _Argument:
    def __init__(  # pylint: disable=redefined-builtin
        self,
        name: str,
        required: bool,
        default: Any,
        nargs: int,
        type: Any,
    ):
        self.name = name
        self.required = required
        self.default = default
        self.nargs = nargs
        self.type = type
        self.param_name = name.replace('-', '_')


def _convert_value(value: str, type_hint: Any) -> Any:
    if type_hint is None or type_hint is str:
        return value
    if type_hint is int:
        return INT.convert(value)
    if type_hint is bool:
        return BOOL.convert(value)
    if isinstance(type_hint, CliType):
        return type_hint.convert(value)
    return value


def _apply_context_settings(cmd: 'Command', context_settings: Optional[Dict[str, Any]]) -> None:
    if not context_settings:
        return
    if 'ignore_unknown_options' in context_settings:
        cmd.ignore_unknown_options = context_settings['ignore_unknown_options']
    if 'allow_interspersed_args' in context_settings:
        cmd.allow_interspersed_args = context_settings['allow_interspersed_args']
    if 'help_option_names' in context_settings:
        cmd.help_option_names = context_settings['help_option_names']


class Command:
    def __init__(  # pylint: disable=redefined-builtin
        self,
        callback: Optional[Callable],
        name: Optional[str],
        help: Optional[str],
        hidden: bool,
    ):
        self.callback = callback
        self.name = name or (callback.__name__ if callback else '')
        self.help = help
        self.hidden = hidden
        self.options: List[_Option] = []
        self.arguments: List[_Argument] = []
        self.version_info: Optional[Tuple[str, str]] = None
        self.help_option_names: List[str] = ['-h', '--help']
        self.ignore_unknown_options = False
        self.allow_interspersed_args = True

    def _format_help(self, prog_name: str) -> str:
        lines: List[str] = []

        usage_parts = [f'Usage: {prog_name}']
        for opt in self.options:
            if not opt.hidden:
                usage_parts.append(f'[{opt.long_name}]')
        for arg in self.arguments:
            if arg.nargs == -1:
                usage_parts.append(f'[{arg.name.upper()}]...')
            elif arg.required:
                usage_parts.append(arg.name.upper())
            else:
                usage_parts.append(f'[{arg.name.upper()}]')
        lines.append(' '.join(usage_parts))

        if self.help:
            lines.append('')
            lines.append(f'  {self.help}')

        visible_options = [opt for opt in self.options if not opt.hidden]
        help_entries: List[Tuple[str, str]] = []

        for opt in visible_options:
            display = opt.get_display_name()
            if not opt.is_flag:
                metavar = 'TEXT'
                if opt.type is int:
                    metavar = 'INTEGER'
                elif opt.type is bool:
                    metavar = 'BOOLEAN'
                elif isinstance(opt.type, CliType):
                    metavar = opt.type.get_metavar()
                display += f'  {metavar}'
            help_text = opt.help or ''
            if opt.required:
                help_text += '  [required]'
            help_entries.append((display, help_text))

        help_names_str = ' / '.join(self.help_option_names)
        help_entries.append((help_names_str, 'Show this message and exit.'))

        if self.version_info:
            help_entries.append(('--version', 'Show the version and exit.'))

        if help_entries:
            lines.append('')
            lines.append('Options:')
            max_left = max(len(entry[0]) for entry in help_entries)
            for left, right in help_entries:
                padding = ' ' * (max_left - len(left) + 2)
                lines.append(f'  {left}{padding}{right}')

        return '\n'.join(lines)

    def _parse_args(self, args: Sequence[str], prog_name: str) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        remaining_args: List[str] = list(args)
        consumed: List[bool] = [False] * len(remaining_args)

        for opt in self.options:
            if opt.is_flag:
                result[opt.param_name] = opt.default if opt.default is not None else False
            else:
                result[opt.param_name] = opt.default

        # Parse options
        i = 0
        stop_parsing_options = False
        while i < len(remaining_args):
            arg = remaining_args[i]

            # Handle '--' end-of-options separator
            if arg == '--' and not stop_parsing_options:
                consumed[i] = True
                stop_parsing_options = True
                i += 1
                continue

            if arg in self.help_option_names and not stop_parsing_options:
                print(self._format_help(prog_name))
                sys.exit(0)

            if self.version_info and arg == '--version' and not stop_parsing_options:
                print(f'{self.version_info[1]}, version {self.version_info[0]}')
                sys.exit(0)

            if arg.startswith('-') and not stop_parsing_options:
                matched = False
                for opt in self.options:
                    if opt.matches(arg):
                        consumed[i] = True
                        if opt.is_flag:
                            result[opt.param_name] = not opt.default if opt.default is not None else True
                        elif '=' in arg:
                            value = arg.split('=', 1)[1]
                            result[opt.param_name] = _convert_value(value, opt.type)
                        else:
                            i += 1
                            if i >= len(remaining_args):
                                raise SystemExit(f"Error: Option '{opt.long_name}' requires an argument.")
                            consumed[i] = True
                            result[opt.param_name] = _convert_value(remaining_args[i], opt.type)
                        matched = True
                        break

                if not matched and not self.ignore_unknown_options:
                    raise SystemExit(f'Error: No such option: {arg}\n\n{self._format_help(prog_name)}')
            elif not arg.startswith('-') and not self.allow_interspersed_args:
                stop_parsing_options = True
            i += 1

        # Collect unconsumed args for positional arguments
        positional = [remaining_args[i] for i in range(len(remaining_args)) if not consumed[i]]

        # Parse positional arguments
        pos_idx = 0
        for arg_def in self.arguments:
            if arg_def.nargs == -1:
                if isinstance(arg_def.type, type(UNPROCESSED)):
                    result[arg_def.param_name] = tuple(positional[pos_idx:])
                else:
                    result[arg_def.param_name] = tuple(_convert_value(v, arg_def.type) for v in positional[pos_idx:])
                pos_idx = len(positional)
            elif pos_idx < len(positional):
                result[arg_def.param_name] = _convert_value(positional[pos_idx], arg_def.type)
                pos_idx += 1
            elif arg_def.required:
                raise SystemExit(f"Error: Missing argument '{arg_def.name.upper()}'.\n\n{self._format_help(prog_name)}")
            else:
                result[arg_def.param_name] = arg_def.default

        if pos_idx < len(positional) and not self.ignore_unknown_options:
            extra = positional[pos_idx:]
            raise SystemExit(
                f'Error: Got unexpected extra argument{"s" if len(extra) > 1 else ""} '
                f'({" ".join(extra)})\n\n{self._format_help(prog_name)}'
            )

        # Check required options
        for opt in self.options:
            if opt.required and result.get(opt.param_name) is None:
                raise SystemExit(f"Error: Missing option '{opt.long_name}'.\n\n{self._format_help(prog_name)}")

        return result

    def __call__(self, *args, **kwargs):
        if args and isinstance(args[0], (list, tuple)):
            return self.main(args[0])
        if args or kwargs:
            return self.main(list(args))
        return self.main(sys.argv[1:])

    def main(self, args: Optional[Sequence[str]] = None, prog_name: Optional[str] = None) -> Any:
        if args is None:
            args = sys.argv[1:]
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv else self.name

        parsed = self._parse_args(args, prog_name)

        if self.callback:
            try:
                return self.callback(**parsed)
            except SystemExit:  # pylint: disable=try-except-raise
                raise
            except Exception as error:
                logger.debug(traceback.format_exc())
                raise SystemExit(f'Error: {error}') from error
        return None


class Group(Command):
    def __init__(  # pylint: disable=redefined-builtin
        self,
        callback: Optional[Callable],
        name: Optional[str],
        help: Optional[str],
        hidden: bool,
    ):
        super().__init__(callback, name, help, hidden)
        self.commands: Dict[str, Command] = {}

    def add_command(self, cmd: Command, name: Optional[str] = None) -> None:
        cmd_name = name or cmd.name
        self.commands[cmd_name] = cmd

    def command(  # pylint: disable=redefined-builtin
        self,
        name: Optional[str] = None,
        help: Optional[str] = None,
        hidden: bool = False,
        **kwargs,
    ) -> Callable:
        def decorator(func: Callable) -> Command:
            cmd = Command(
                callback=func,
                name=name or func.__name__.replace('_', '-'),
                help=help,
                hidden=hidden,
            )
            _apply_context_settings(cmd, kwargs.get('context_settings'))
            _collect_pending_metadata(func, cmd)
            self.commands[cmd.name] = cmd
            return cmd

        return decorator

    def group(  # pylint: disable=redefined-builtin
        self,
        name: Optional[str] = None,
        help: Optional[str] = None,
        hidden: bool = False,
        **kwargs,  # pylint: disable=unused-argument
    ) -> Callable:
        def decorator(func: Callable) -> 'Group':
            grp = Group(
                callback=func,
                name=name or func.__name__.replace('_', '-'),
                help=help,
                hidden=hidden,
            )
            _collect_pending_metadata(func, grp)
            self.commands[grp.name] = grp
            return grp

        return decorator

    def _format_help(self, prog_name: str) -> str:
        base_help = super()._format_help(prog_name + ' [OPTIONS] COMMAND [ARGS]...')

        visible_commands = {name: cmd for name, cmd in self.commands.items() if not cmd.hidden}

        if not visible_commands:
            return base_help

        lines = [base_help, '', 'Commands:']
        max_name_len = max(len(name) for name in visible_commands) if visible_commands else 0

        for name in sorted(visible_commands):
            cmd = visible_commands[name]
            padding = ' ' * (max_name_len - len(name) + 2)
            cmd_help = cmd.help or ''
            lines.append(f'  {name}{padding}{cmd_help}')

        return '\n'.join(lines)

    def main(self, args: Optional[Sequence[str]] = None, prog_name: Optional[str] = None) -> Any:
        if args is None:
            args = sys.argv[1:]
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv else self.name

        # Find the first non-option arg as the subcommand
        group_args: List[str] = []
        subcommand_name: Optional[str] = None
        subcommand_args: List[str] = []
        found_subcommand = False

        skip_next = False
        for i, arg in enumerate(args):
            if skip_next:
                skip_next = False
                continue
            if found_subcommand:
                subcommand_args.append(arg)
            elif arg in self.help_option_names:
                print(self._format_help(prog_name))
                sys.exit(0)
            elif self.version_info and arg == '--version':
                print(f'{self.version_info[1]}, version {self.version_info[0]}')
                sys.exit(0)
            elif not arg.startswith('-') and arg in self.commands:
                subcommand_name = arg
                found_subcommand = True
            elif arg.startswith('-'):
                matched_opt = None
                for opt in self.options:
                    if opt.matches(arg):
                        matched_opt = opt
                        break
                group_args.append(arg)
                if matched_opt and not matched_opt.is_flag and '=' not in arg and i + 1 < len(args):
                    group_args.append(args[i + 1])
                    skip_next = True
            else:
                raise SystemExit(f"Error: No such command '{arg}'.\n\n{self._format_help(prog_name)}")

        # Parse group-level args and invoke callback
        parsed = self._parse_args(group_args, prog_name)
        if self.callback:
            try:
                self.callback(**parsed)
            except SystemExit:  # pylint: disable=try-except-raise
                raise
            except Exception as error:
                logger.debug(traceback.format_exc())
                raise SystemExit(f'Error: {error}') from error

        if subcommand_name is None:
            print(self._format_help(prog_name))
            sys.exit(0)

        cmd = self.commands[subcommand_name]
        return cmd.main(subcommand_args, prog_name=f'{prog_name} {subcommand_name}')


def option(  # pylint: disable=redefined-builtin
    *param_decls: str,
    is_flag: bool = False,
    default: Any = None,
    required: bool = False,
    type: Any = None,
    help: Optional[str] = None,
    hidden: bool = False,
) -> Callable:
    # Separate explicit param name from option flags (e.g. '--json', 'output_as_json')
    explicit_name: Optional[str] = None
    flag_decls: Tuple[str, ...] = param_decls
    non_flag_decls = [d for d in param_decls if not d.startswith('-')]
    if non_flag_decls:
        explicit_name = non_flag_decls[0]
        flag_decls = tuple(d for d in param_decls if d.startswith('-'))

    def decorator(cmd_or_func: Any) -> Any:
        opt = _Option(
            param_decls=flag_decls,
            is_flag=is_flag,
            default=default,
            required=required,
            type=type,
            help=help,
            hidden=hidden,
            explicit_name=explicit_name,
        )
        if isinstance(cmd_or_func, Command):
            cmd_or_func.options.insert(0, opt)
            return cmd_or_func
        if not hasattr(cmd_or_func, '_cli_pending_options'):
            cmd_or_func._cli_pending_options = []  # pylint: disable=protected-access
        cmd_or_func._cli_pending_options.append(opt)  # pylint: disable=protected-access
        return cmd_or_func

    return decorator


def argument(  # pylint: disable=redefined-builtin
    name: str,
    required: bool = True,
    default: Any = None,
    nargs: int = 1,
    type: Any = None,
) -> Callable:
    def decorator(cmd_or_func: Any) -> Any:
        arg = _Argument(
            name=name,
            required=required,
            default=default,
            nargs=nargs,
            type=type,
        )
        if isinstance(cmd_or_func, Command):
            cmd_or_func.arguments.insert(0, arg)
            return cmd_or_func
        if not hasattr(cmd_or_func, '_cli_pending_arguments'):
            cmd_or_func._cli_pending_arguments = []  # pylint: disable=protected-access
        cmd_or_func._cli_pending_arguments.append(arg)  # pylint: disable=protected-access
        return cmd_or_func

    return decorator


def version_option(
    version: str,
    prog_name: str = '',
) -> Callable:
    def decorator(cmd_or_func: Any) -> Any:
        if isinstance(cmd_or_func, Command):
            cmd_or_func.version_info = (version, prog_name)
            return cmd_or_func
        cmd_or_func._cli_pending_version_info = (version, prog_name)  # pylint: disable=protected-access
        return cmd_or_func

    return decorator


def _collect_pending_metadata(func: Callable, cmd: Command) -> None:
    if hasattr(func, '_cli_pending_options'):
        for opt in func._cli_pending_options:  # pylint: disable=protected-access
            cmd.options.insert(0, opt)
    if hasattr(func, '_cli_pending_arguments'):
        for arg in func._cli_pending_arguments:  # pylint: disable=protected-access
            cmd.arguments.insert(0, arg)
    if hasattr(func, '_cli_pending_version_info'):
        cmd.version_info = func._cli_pending_version_info  # pylint: disable=protected-access


def command(  # pylint: disable=redefined-builtin
    name: Optional[str] = None,
    help: Optional[str] = None,
    hidden: bool = False,
    context_settings: Optional[Dict[str, Any]] = None,
    **kwargs,  # pylint: disable=unused-argument
) -> Callable:
    def decorator(func: Callable) -> Command:
        cmd = Command(
            callback=func,
            name=name or func.__name__.replace('_', '-'),
            help=help,
            hidden=hidden,
        )
        _apply_context_settings(cmd, context_settings)
        _collect_pending_metadata(func, cmd)
        return cmd

    return decorator


def group(  # pylint: disable=redefined-builtin
    name: Optional[str] = None,
    help: Optional[str] = None,
    hidden: bool = False,
    context_settings: Optional[Dict[str, Any]] = None,
    **kwargs,  # pylint: disable=unused-argument
) -> Callable:
    def decorator(func: Callable) -> Group:
        grp = Group(
            callback=func,
            name=name or func.__name__.replace('_', '-'),
            help=help,
            hidden=hidden,
        )
        _apply_context_settings(grp, context_settings)
        _collect_pending_metadata(func, grp)
        return grp

    return decorator
