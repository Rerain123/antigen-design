---
applyTo: "**/*.ts,**/*.tsx,**/package.json,**/vite.config.*,**/.npmrc,**/package-lock.json,**/gui/**"
---

Apply the [general coding guidelines](./style-general.instructions.md) to all code.

# General Project Guidelines
- Prefer using `export default function` over exporting at the end of the file.

# Package Management
- **Always use npm** for all package management operations
- Use `npm install` to install dependencies
- Use `npm install <package>` to add a runtime dependency
- Use `npm install -D <package>` to add a development dependency
- Use `npm uninstall <package>` to remove a dependency
- Use `npm run dev` for local development
- Use `npm run build` for production builds

# Build Process
- BioLib GUI projects use Vite for building and development
- The build process compiles TypeScript and React into a single HTML file
- Always run `npm run build` to create the production build before deployment
- Use `npm run dev` for local development with hot reloading

# Configuration Files
- The `.npmrc` file configures npm settings including `ignore-scripts=true` and `min-release-age=7`
- Never modify package-lock.json manually - let npm manage it automatically

# Dependencies
- Add new dependencies using `npm install <package>` for runtime dependencies
- Add development dependencies using `npm install -D <package>`
- Keep dependencies up to date but test thoroughly after updates

# TypeScript Guidelines
- Use TypeScript for all new code
- Follow functional programming principles where possible
- Use interfaces for data structures prefixed with I like `interface IRecord`
- Prefer immutable data (const, readonly)
- Use optional chaining (?.) and nullish coalescing (??) operators

# React Guidelines
- Use functional components with hooks
- Follow the React hooks rules (no conditional hooks)
- Prefer one component per file
- Use Tailwindcss for styling
- Extract props in components with object destructuring like `const { prop1, prop2 } = props;`
- Instantiate functional components with props like `export default function MyComponent(props: IProps) { ... }`.
