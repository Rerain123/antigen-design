# Local workflow engineering report

Scientific Gate: CLOSED; DEVELOPMENT_UNREVIEWED; NOT_DEPLOYED.

| Node | Branch | State | Reason | Origin |
|---|---|---|---|---|
| N15 | base_report | skipped | DESIGN_NOT_EXECUTED |  |
| N04 | bepipred | succeeded |  | NEW_EXECUTION |
| N03 | blast | succeeded |  | NEW_EXECUTION |
| N16 | codon | skipped | NO_QUALIFIED_CANDIDATE |  |
| N11 | design | skipped | R57_LOW_CONFIDENCE_DESIGN_SKIPPED |  |
| N12 | design_audit | skipped | DESIGN_NOT_EXECUTED |  |
| N10 | developability | succeeded |  | NEW_EXECUTION |
| N09 | domains | unavailable | DATABASE_NOT_PROVIDED |  |
| N06 | epitope_map | succeeded |  | NEW_EXECUTION |
| N07 | glycosylation | succeeded |  | NEW_EXECUTION |
| N08 | homology | unavailable | DATABASE_NOT_PROVIDED |  |
| N18 | local_delivery | succeeded |  | NEW_EXECUTION |
| N05 | netmhc | succeeded |  | NEW_EXECUTION |
| N13 | protection | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep1_bepipred | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep1_developability | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep1_epitope_map | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep1_glycosylation | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep1_netmhc | skipped | DESIGN_NOT_EXECUTED |  |
| N12 | rep1_prediction | skipped | DESIGN_NOT_EXECUTED |  |
| N12 | rep1_structure | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep2_bepipred | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep2_developability | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep2_epitope_map | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep2_glycosylation | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep2_netmhc | skipped | DESIGN_NOT_EXECUTED |  |
| N12 | rep2_prediction | skipped | DESIGN_NOT_EXECUTED |  |
| N12 | rep2_structure | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep3_bepipred | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep3_developability | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep3_epitope_map | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep3_glycosylation | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | rep3_netmhc | skipped | DESIGN_NOT_EXECUTED |  |
| N12 | rep3_prediction | skipped | DESIGN_NOT_EXECUTED |  |
| N12 | rep3_structure | skipped | DESIGN_NOT_EXECUTED |  |
| N12 | rescore | skipped | DESIGN_NOT_EXECUTED |  |
| N15 | selection_report | skipped | DESIGN_NOT_EXECUTED |  |
| N14 | stability | skipped | DESIGN_NOT_EXECUTED |  |
| N01 | structure | succeeded |  | NEW_EXECUTION |
| N02 | topology | succeeded |  | NEW_EXECUTION |
| N15 | variant_report | succeeded |  | NEW_EXECUTION |
| N13 | wt_bepipred | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | wt_developability | skipped | DESIGN_NOT_EXECUTED |  |
| N18 | wt_draft | succeeded |  | NEW_EXECUTION |
| N13 | wt_epitope_map | skipped | DESIGN_NOT_EXECUTED |  |
| N17 | wt_foldx | skipped | LOW_CONFIDENCE_SCAN_SKIPPED |  |
| N13 | wt_glycosylation | skipped | DESIGN_NOT_EXECUTED |  |
| N13 | wt_netmhc | skipped | DESIGN_NOT_EXECUTED |  |
| N17 | wt_reference | succeeded |  | NEW_EXECUTION |
| N17 | wt_thermompnn | skipped | LOW_CONFIDENCE_SCAN_SKIPPED |  |
