# Local workflow engineering report

Scientific Gate: CLOSED; DEVELOPMENT_UNREVIEWED; NOT_DEPLOYED.

| Node | Branch | State | Reason | Origin |
|---|---|---|---|---|
| N15 | base_report | succeeded |  | NEW_EXECUTION |
| N04 | bepipred | succeeded |  | NEW_EXECUTION |
| N03 | blast | succeeded |  | NEW_EXECUTION |
| N16 | codon | skipped | NO_QUALIFIED_CANDIDATE |  |
| N11 | design | succeeded |  | NEW_EXECUTION |
| N12 | design_audit | succeeded |  | NEW_EXECUTION |
| N10 | developability | succeeded |  | NEW_EXECUTION |
| N09 | domains | unavailable | DATABASE_NOT_PROVIDED |  |
| N06 | epitope_map | succeeded |  | NEW_EXECUTION |
| N07 | glycosylation | succeeded |  | NEW_EXECUTION |
| N08 | homology | unavailable | DATABASE_NOT_PROVIDED |  |
| N18 | local_delivery | succeeded |  | NEW_EXECUTION |
| N05 | netmhc | succeeded |  | NEW_EXECUTION |
| N13 | protection | succeeded |  | NEW_EXECUTION |
| N13 | rep1_bepipred | succeeded |  | NEW_EXECUTION |
| N13 | rep1_developability | succeeded |  | NEW_EXECUTION |
| N13 | rep1_epitope_map | succeeded |  | NEW_EXECUTION |
| N13 | rep1_glycosylation | succeeded |  | NEW_EXECUTION |
| N13 | rep1_netmhc | succeeded |  | NEW_EXECUTION |
| N12 | rep1_prediction | succeeded |  | NEW_EXECUTION |
| N12 | rep1_structure | succeeded |  | NEW_EXECUTION |
| N13 | rep2_bepipred | succeeded |  | NEW_EXECUTION |
| N13 | rep2_developability | succeeded |  | NEW_EXECUTION |
| N13 | rep2_epitope_map | succeeded |  | NEW_EXECUTION |
| N13 | rep2_glycosylation | succeeded |  | NEW_EXECUTION |
| N13 | rep2_netmhc | succeeded |  | NEW_EXECUTION |
| N12 | rep2_prediction | succeeded |  | NEW_EXECUTION |
| N12 | rep2_structure | succeeded |  | NEW_EXECUTION |
| N13 | rep3_bepipred | succeeded |  | NEW_EXECUTION |
| N13 | rep3_developability | succeeded |  | NEW_EXECUTION |
| N13 | rep3_epitope_map | succeeded |  | NEW_EXECUTION |
| N13 | rep3_glycosylation | succeeded |  | NEW_EXECUTION |
| N13 | rep3_netmhc | succeeded |  | NEW_EXECUTION |
| N12 | rep3_prediction | succeeded |  | NEW_EXECUTION |
| N12 | rep3_structure | succeeded |  | NEW_EXECUTION |
| N12 | rescore | succeeded |  | NEW_EXECUTION |
| N15 | selection_report | succeeded |  | NEW_EXECUTION |
| N14 | stability | succeeded |  | NEW_EXECUTION |
| N01 | structure | succeeded |  | NEW_EXECUTION |
| N02 | topology | succeeded |  | NEW_EXECUTION |
| N15 | variant_report | succeeded |  | NEW_EXECUTION |
| N13 | wt_bepipred | succeeded |  | NEW_EXECUTION |
| N13 | wt_developability | succeeded |  | NEW_EXECUTION |
| N18 | wt_draft | succeeded |  | NEW_EXECUTION |
| N13 | wt_epitope_map | succeeded |  | NEW_EXECUTION |
| N17 | wt_foldx | succeeded |  | NEW_EXECUTION |
| N13 | wt_glycosylation | succeeded |  | NEW_EXECUTION |
| N13 | wt_netmhc | succeeded |  | NEW_EXECUTION |
| N17 | wt_reference | succeeded |  | NEW_EXECUTION |
| N17 | wt_thermompnn | succeeded |  | NEW_EXECUTION |
